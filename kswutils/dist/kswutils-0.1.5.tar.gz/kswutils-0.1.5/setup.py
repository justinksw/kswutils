from setuptools import setup

setup(
    name='kswutils',
    version='0.1.5',
    description='Justin utils at work',
    packages=['kswutils'],
    author_email='shuwa108@gmail.com',
    zip_safe=False
)
